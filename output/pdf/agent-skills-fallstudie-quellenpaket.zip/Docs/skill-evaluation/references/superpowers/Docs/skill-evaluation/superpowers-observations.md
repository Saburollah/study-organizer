# Beobachtungslog: Superpowers-Versuch

## Versuchsmetadaten

| Merkmal | Wert |
| --- | --- |
| Versuch | Obras Superpowers |
| Branch | `experiment/superpowers` |
| Separater Worktree | Ja: `.worktrees/superpowers` |
| Gemeinsamer Feature-Ausgangscommit | `e7d8b5ecc3fe75a38655f16c4636328bb1598d57` |
| Experiment-Setup-Commit | `1c4b35aef923328a9ff0e3afba501dcf923e0c1a` |
| Superpowers-Version | `superpowers-v6.3.0` |
| Superpowers-Skill-Commit | `a41901651ce44a66c2fea78dda4f81e8a3815fbe` |
| Beginn | 27. August 2026, ca. 21:00 CEST; nachträglich näherungsweise erfasst |
| Aktuelle Agentensitzung | 1 |

Der Setup-Commit liegt direkt auf dem gemeinsamen Ausgangscommit. Sein Diff ändert nur den Submodule-Pointer von `.agents/skills` und neutrale Metadaten in `experiment-protocol.md`. Vor der Baseline war der Arbeitsbaum sauber. `AGENTS.md` war nicht vorhanden.

## Laufende objektive Messwerte

| Messwert | Aktueller Wert | Erläuterung |
| --- | ---: | --- |
| Agentensitzungen | 1 | Beginn von S0 und S1 in derselben Sitzung |
| Subagent-Aufrufe | 22 | Tasks 1–3: acht; Task 4: fünf; Task 5: fünf; Task 6: Implementierung, Review, beendeter Fixturn und gestoppter Verifikationsturn |
| Rückfragen an den Benutzer | 31 | Zwanzig Fragen bis S2, eine S4-Integrationsentscheidung sowie sieben S5-Bewertungsfragen und drei Rückfragen für konkrete Beispiele beziehungsweise eine verständlichere Erklärung |
| Davon Produkt-/Architekturfragen | 17 | Zehn Klärungsfragen, eine Ansatzwahl, fünf Designfreigaben und eine Konsistenzfrage |
| Umgebungsfreigaben | 33 | Baseline-/Commit-Ausnahmen sowie Named-Pipe-, Prozess-, Socket-, Startup- und finale Testfreigaben im eingeschränkten Worktree |
| Vom Benutzer korrigierte Annahmen | 1 | Der nur scheinbar aktive `.csproj`-Start wurde zu früh als erfolgreicher Development-Start bewertet; der manuelle Walkthrough widerlegte dies |
| Planungs- und Entscheidungsdokumente | 2 | Bestätigte Moodle-Designspezifikation und ausführbarer Implementierungsplan; das Beobachtungslog wird nicht mitgezählt |
| Implementierungsplanaufgaben | 12 | Tasks 1–12 abgeschlossen; Tasks 7–12 vollständig inline ausgeführt |
| Fehlgeschlagene oder wiederholte Implementierungsversuche | 2 | Task 4: erster GREEN-Lauf scheiterte in zwei Tests an SQLite-`DateTimeOffset`-Sortierung; verworfener Parallel-Context-Ansatz für deterministische Race-Tests |
| Neu angelegte automatisierte Tests | 155 | Task 1: 35; Task 2: 6; Task 3: 5; Task 4: 26; Task 5: 16; Task 6: 19; Task 7: 11; Task 8: 17; Task 9: 4; Task 10: 14; Task 11: 2 |
| Review-Funde nach Schweregrad | 1 / 6 / 4 | Critical / Important / Minor; Critical und Important behoben, ein Dokumentations-Minor im Gesamt-Review behoben, drei nicht blockierende Minor akzeptiert |
| Geänderte Produktdateien | 84 | `backend/` und `frontend/` gegen `e7d8b5e`: 8.368 Zeilen hinzugefügt, 79 entfernt; Dokumentation/Versuchsmetadaten nicht enthalten |

## Baseline-Ergebnisse

Die Produkt-Baseline wurde am 27. August 2026 abgeschlossen. Backend-Befehle mussten wegen der von MSBuild benötigten lokalen Named Pipes außerhalb der eingeschränkten Sandbox wiederholt werden. Frontend-Abhängigkeiten wurden vor der aussagekräftigen Prüfung mit `pnpm install --frozen-lockfile` aus dem vorhandenen Lockfile und vollständig aus dem lokalen Paketcache installiert. Das Lockfile blieb unverändert.

| Prüfung | Ergebnis | Nachweis |
| --- | --- | --- |
| `dotnet build backend/StudyOrganizer.sln` | Bestanden | Exit 0; 0 Warnungen; 0 Fehler; gemeldete Buildzeit 1,48 s |
| `dotnet test backend/StudyOrganizer.sln` | Baseline-Fehler | Domain: 17/17 bestanden. API: 0/43 bestanden; alle 43 Tests scheitern beim Hoststart mit `InvalidOperationException: JWT configuration is incomplete or invalid.`; Exit 1 |
| `cd frontend && pnpm type-check` | Bestanden | Exit 0 nach Installation der Lockfile-Abhängigkeiten |
| `cd frontend && pnpm lint` | Bestanden | Exit 0; keine versionierten Änderungen durch die `--fix`-Skripte |
| `cd frontend && pnpm exec vitest run` | Bestanden | 17/17 Testdateien, 77/77 Tests; Exit 0; gemeldete Dauer 2,47 s |
| `cd frontend && pnpm build` | Bestanden | Exit 0; 86 Module transformiert; Vite-Build in 472 ms |

### Abgrenzung des Backend-Baseline-Fehlers

Der API-Testfehler bestand vor jeder Moodle-Implementierung im isolierten Superpowers-Branch. Er wird deshalb gemäß Versuchsprotokoll weder der Skill-Suite noch dem Moodle-Feature zugerechnet. Vor der Implementierung muss entschieden werden, wie er für Abschlussprüfungen reproduzierbar konfiguriert wird; in S0 wurde er bewusst nicht repariert.

### Setup- und Umgebungsereignisse

1. Der erste Sandbox-Lauf von `dotnet build` blieb mehr als zwei Minuten ohne Ausgabe hängen und wurde abgebrochen. Derselbe Befehl bestand außerhalb der Sandbox.
2. Der erste Sandbox-Lauf von `dotnet test` scheiterte mit `System.Net.Sockets.SocketException (13): Permission denied`, weil MSBuild keine lokale Named Pipe binden durfte. Derselbe Befehl lief außerhalb der Sandbox bis zu den beschriebenen Produkttests.
3. Der erste Aufruf von `pnpm type-check` konnte `vue-tsc` nicht finden, weil `frontend/node_modules` fehlte. Nach `pnpm install --frozen-lockfile` bestand die Typprüfung.
4. Die Baseline erzeugte nur ignorierte Arbeitsartefakte: `frontend/node_modules/`, `frontend/dist/` und `frontend/.eslintcache`. Der Git-Diff blieb bis zur Anlage dieses Logs leer.

## Beobachtungslog pro Phase

### Superpowers S0 — Isolation und Baseline

- **Beginn/Ende:** 27. August 2026, ca. 21:00–21:13 CEST; Beginn nachträglich näherungsweise erfasst
- **Verwendete Skills:** `using-superpowers`, danach `brainstorming` zur Prozessklassifikation; noch keine Implementierungs-Skills
- **Erzeugte Artefakte:** `Docs/skill-evaluation/superpowers-observations.md`
- **Gestellte Rückfragen:** Keine Produktfrage; drei technische Freigaben für reproduzierbare Baseline-Ausführung
- **Wichtige Entscheidungen:** Aufgabe als architektonischen Brainstorming-Pfad klassifiziert; Baseline- und Umgebungsfehler getrennt; keine Reparatur des vorbestehenden JWT-Problems in S0
- **Fehlversuche oder Blocker:** Sandbox-Hänger beim Build; Named-Pipe-Verbot bei Tests; fehlende Frontend-Abhängigkeiten; vorbestehender JWT-Konfigurationsfehler in allen 43 API-Tests
- **Korrekturen durch den Benutzer:** Keine
- **Besonders hilfreich:** Das Protokoll gab identische, konkrete Prüfbefehle und die Regel zur Behandlung vorbestehender Fehler vor
- **Unnötig oder zu aufwendig:** **Agentenentwurf:** Die Sandbox-bedingten Wiederholungen erhöhten den Zeit- und Freigabeaufwand, ohne Produktwissen zu erzeugen
- **Vom Skill übersehen:** **Agentenentwurf:** `brainstorming` selbst definiert keine Experiment-Baseline; die nötige Trennung kam aus dem projektspezifischen Versuchsprotokoll
- **Was ich selbst gelernt habe:** **Vom Benutzer bestätigt:** „Ich habe gelernt, dass ein eigener Worktree den Superpowers-Versuch vom Matt-Versuch und von main trennt. Die Baseline-Prüfung zeigt, dass das Projekt vor der neuen Implementierung funktioniert, sodass spätere Fehler eindeutig unseren Änderungen zugeordnet werden können.“
- **Nachweis:** Branch `experiment/superpowers`; Ausgangscommit `e7d8b5e`; Setup-Commit `1c4b35a`; Skill-Commit `a419016`; obige Testausgaben; dieses Dokument

## Abschließende Einordnung von S0

- Die tatsächliche manuelle Arbeitszeit des Benutzers wurde nicht separat
  gemessen und wird im Vergleich deshalb als „nicht erhoben“ ausgewiesen.
- Die eigene Erklärung des Benutzers zu Worktree-Isolation und Baseline zeigt,
  dass beide Zwecke verständlich waren.
- Der Benutzer bewertete den Gesamtaufwand in S5 mit 5/5. Die häufigen
  Sandbox-Freigaben bleiben dennoch als agentenseitige Ineffizienz dokumentiert.

### Superpowers S1 — Brainstorming (abgeschlossen)

- **Beginn/Ende:** 27. August 2026 nach Abschluss von S0 bis 28. August 2026, ca. 12:00 CEST
- **Verwendete Skills:** `brainstorming`
- **Erzeugte Artefakte:** `Docs/superpowers/specs/2026-08-27-moodle-end-to-end-design.md`
- **Gestellte Rückfragen:** 1. Welchen Umfang soll der erste vertikale Moodle-Schnitt haben? 2. Was ist der Hauptgrund für diese Wahl? 3. Wie sollen erkannte Moodle-Inhalte zu persönlichen Aufgaben werden? 4. Was ist der Hauptgrund für diese Aufgabenregel? 5. Wie weit soll der Zustand `Prüfung erforderlich` im ersten Schnitt bedienbar sein? 6. Welchem persönlichen Lernmodul sollen automatisch erzeugte Aufgaben zugeordnet werden? 7. Wie wird derselbe externe Kurs trotz unterschiedlicher Links kanonisch erkannt? 8. Wie wirken Änderungen externer Inhalte auf bereits erzeugte Aufgaben? 9. Wann gilt eine externe Frist im ersten Schnitt als verlässlich? 10. Wie erhält ein später Abonnent bereits bekannte Kursinhalte? 11. Welcher Architekturansatz soll den bestätigten Schnitt tragen? 12. Ist der Designabschnitt zu Systemgrenzen und Datenmodell korrekt? 13. Ist der Designabschnitt zu Registrierung und Scanablauf korrekt? 14. Ist der Designabschnitt zu Fehlern und sicheren Zustandsänderungen korrekt? 15. Ist der Designabschnitt zu API und Benutzeroberfläche korrekt? 16. Ist der Designabschnitt zu Tests, Abnahme und ausgeschlossenem Umfang korrekt? 17. Dürfen automatisch erzeugte Aufgaben lokal bearbeitet oder gelöscht werden? 18. Schriftliche Prüfung der Designspezifikation. Der Benutzer antwortete `Nein`, also keine Änderungswünsche; damit war die Spezifikation bestätigt.
- **Wichtige Entscheidungen:** **Vom Benutzer bestätigt:** Variante A, ein lokaler End-to-End-Schnitt. Er umfasst Kursregistrierung über die UI, manuellen Scan einer deterministischen Mock-Quelle, sichtbare erkannte Inhalte sowie automatisierte Nachweise für Deduplizierung und mehrere Abonnenten. Reale Moodle-Anbindung, Scheduler und reale Benachrichtigungen sind zunächst ausgeschlossen.

  **Begründung des Benutzers:** „Ich bevorzuge den lokalen End-to-End-Schnitt, weil ich damit den vollständigen Ablauf vom Registrieren eines Kurses bis zur erzeugten Aufgabe testen kann. Der Mock macht die Tests reproduzierbar und unabhängig von Zugangsdaten oder der Verfügbarkeit eines echten Moodle-Systems, während trotzdem Architektur, Benutzeroberfläche und Deduplizierung gemeinsam geprüft werden.“

  **Vom Benutzer bestätigte Aufgabenregel:** Neue externe Inhalte erzeugen pro Abonnent genau dann automatisch eine persönliche Aufgabe, wenn die Quelle eine verlässliche Abgabefrist liefert. Inhalte ohne oder mit unsicherer Frist erzeugen keine Aufgabe und werden als `Prüfung erforderlich` markiert.

  **Begründung des Benutzers:** „Eine automatisch erzeugte Aufgabe soll zuverlässig sein, damit normale Hinweise oder andere Inhalte nicht fälschlich als Aufgaben erscheinen. Wenn die Moodle-Frist unsicher ist, soll das Programm den Inhalt lieber zur Prüfung markieren, statt eine möglicherweise falsche Aufgabe mit falschem Termin anzulegen.“

  **Vom Benutzer bestätigter Umfang des Prüfzustands:** Ein als `Prüfung erforderlich` markierter Inhalt zeigt im ersten Schnitt Titel, Quelle und den Grund der Unsicherheit. Er kann dort noch nicht bestätigt oder in eine Aufgabe umgewandelt werden.

  **Vom Benutzer bestätigte Modulzuordnung:** Beim ersten Abonnement wird für den Benutzer automatisch ein persönliches `StudyModule` mit dem erkannten Kursnamen angelegt. Das `CourseSubscription` verbindet dieses Modul mit dem gemeinsam gespeicherten `ExternalCourse`. Mehrere Abonnenten teilen dadurch den externen Kurs und seine Scans, besitzen aber getrennte Module und Aufgaben.

  **Vom Benutzer bestätigte Kursidentität:** Der Mock-Adapter liefert eine stabile Identität aus `provider + externalCourseId`. Der eingegebene Link ist nicht der eindeutige Kursschlüssel; unterschiedliche Links dürfen auf denselben gemeinsam gespeicherten Kurs und denselben Scanlauf zeigen.

  **Vom Benutzer bestätigtes Änderungsverhalten:** Bei unveränderter externer Inhalts-ID werden Titel, Beschreibung und Frist einer offenen automatisch erzeugten Aufgabe mit der Quelle synchronisiert. Aufgaben-ID und Bearbeitungsstatus bleiben erhalten. Erledigte Aufgaben werden nicht nachträglich verändert.

  **Vom Benutzer bestätigte Vertrauensgrenze:** Eine Frist gilt im ersten Schnitt nur dann als verlässlich, wenn der Adapter für einen als Aufgabe normalisierten Inhalt ein strukturiertes Fristfeld liefert. Datumsangaben in Titel oder Beschreibung werden nicht interpretiert; Confidence-Schwellen und LLM-Erkennung sind ausgeschlossen.

  **Vom Benutzer bestätigtes Verhalten für späte Abonnenten:** Ein neuer Abonnent erhält ohne erneuten externen Abruf persönliche Aufgaben aus den noch relevanten Inhalten des letzten erfolgreichen gemeinsamen Snapshots. Die Zuordnung bleibt pro Abonnement und externem Inhalt idempotent.

  **Vom Benutzer bestätigter Architekturansatz:** Explizites gemeinsames Domänenmodell mit relational gespeicherten Kursen, Abonnements, normalisierten Inhalten, Scanläufen und idempotenten Zuordnungen zu persönlichen Aufgaben. Snapshot-JSON und Ereignisprotokoll sind für den ersten Schnitt verworfen.

  **Vom Benutzer bestätigter Designabschnitt 1 — Systemgrenzen und Datenmodell:** `ExternalCourse` ist gemeinsam; `CourseSubscription`, persönliches `StudyModule`, `ExternalTaskLink` und `StudyTask` trennen die Benutzerdaten. `ExternalContent` repräsentiert den letzten erfolgreichen normalisierten Zustand; `ScanRun` dokumentiert Abrufe. Der Adapter-Port liefert Discovery und Snapshot, im ersten Schnitt ausschließlich über einen Mock-Adapter.

  **Vom Benutzer bestätigter Designabschnitt 2 — Registrierung und Scan:** Discovery legt Kurs, Abonnement und persönliches Modul idempotent an. Späte Abonnenten verwenden relevante Inhalte des letzten erfolgreichen Snapshots. Ein manueller gemeinsamer Scan validiert und vergleicht den Snapshot vollständig und schreibt Inhalte, Aufgabenverknüpfungen und erfolgreichen Scanlauf atomar.

  **Vom Benutzer bestätigter Designabschnitt 3 — Fehler und Sicherheit:** Ungültige Registrierung erzeugt keine Daten. Fehlerhafte oder nicht vertrauenswürdige Scans erhalten den letzten erfolgreichen Zustand und protokollieren nur sichere Fehlerdaten. Gleichzeitige Scans werden verhindert; verschwundene Inhalte löschen keine Aufgaben; verlorene Fristverlässlichkeit führt zu `Prüfung erforderlich`.

  **Vom Benutzer bestätigter Designabschnitt 4 — API und UI:** Eine geschützte, zweisprachige Moodle-Kursansicht registriert Fixture-Links, listet eigene Abonnements und Inhalte und startet gemeinsame manuelle Scans. Erzeugte Aufgaben erscheinen mit Moodle-Quellenhinweis im automatisch angelegten persönlichen Modul. Benutzerbezogene Endpunkte autorisieren stets über das Abonnement.

  **Vom Benutzer bestätigter Designabschnitt 5 — Tests und Abnahme:** Kontrollierbare Ausgangs-, Änderungs- und Fehlerzustände des Mock-Adapters belegen Registrierung, gemeinsamen Scan, Deduplizierung, Aufgabenregeln, Synchronisierung, späte Abonnenten, Fehlererhalt und Autorisierung. Reale Moodle-Zugänge, Scheduler, Benachrichtigungen, LLM, manueller Prüfworkflow, Abonnementlöschung und iOS sind ausgeschlossen.

  **Vom Benutzer bestätigte Konsistenzregel:** Moodle-gesteuerte Aufgaben erlauben nur Statusänderungen. Titel, Beschreibung, Frist, Bearbeiten und Löschen bleiben quellengesteuert. Der Spec-Self-Review ergänzte daraus folgend den Löschschutz für das mit einem aktiven Abonnement verbundene persönliche Modul; andere Modulfelder bleiben persönlich bearbeitbar.
- **Fehlversuche oder Blocker:** Keine
- **Korrekturen durch den Benutzer:** Keine
- **Besonders hilfreich:** Die abschnittsweisen Freigaben hielten Produktentscheidungen sichtbar; der vorgeschriebene Spec-Self-Review fand die zuvor nicht geregelte Löschung des verknüpften persönlichen Moduls.
- **Unnötig oder zu aufwendig:** **Agentenentwurf:** Die fünf abschnittsweisen Freigaben erhöhten die Zahl der Interaktionen deutlich; sie schufen jedoch nachvollziehbare Entscheidungspunkte für den Versuch.
- **Vom Skill übersehen:** **Agentenentwurf:** Die Löschregel für das automatisch verknüpfte persönliche Modul wurde nicht durch eine Skill-Frage entdeckt, sondern erst durch den verpflichtenden Konsistenz-Self-Review der fertigen Spezifikation.
- **Was ich selbst gelernt habe:** **Vom Benutzer bestätigt:** Der lokale
  End-to-End-Schnitt prüft den vollständigen Ablauf von der Kursregistrierung
  bis zur Aufgabe. Der Mock hält ihn reproduzierbar und unabhängig von echten
  Moodle-Zugangsdaten, ohne Architektur, UI und Deduplizierung getrennt zu
  betrachten.
- **Nachweis:** `Docs/superpowers/specs/2026-08-27-moodle-end-to-end-design.md`; Commit `3dc5ff5`

### Superpowers S2 — Arbeitsumgebung und Plan (abgeschlossen)

- **Beginn/Ende:** 28. August 2026, nach Bestätigung der Spezifikation bis ca. 12:45 CEST
- **Verwendete Skills:** `writing-plans`; `using-git-worktrees` zur erneuten Prüfung der bereits bestehenden Isolation
- **Erzeugte Artefakte:** `Docs/superpowers/plans/2026-08-28-moodle-end-to-end.md` mit 12 geordneten Aufgaben
- **Gestellte Rückfragen:** Auswahl zwischen subagentengesteuerter und
  Inline-Ausführung bei der Planübergabe; zunächst Option 1
  (subagentengesteuert), nach Task 6 auf ausdrücklichen Benutzerwunsch Wechsel
  zur Inline-Ausführung für Tasks 7–12
- **Wichtige Entscheidungen:** Der Plan führt Domain, Provider-Port und Snapshot-Diff, relationale Persistenz, Registrierung, gemeinsamen Scan, Fehler- und Nebenläufigkeitsverhalten, Schutz quellengesteuerter Daten, API, Frontend und Abschlussnachweise in dieser Abhängigkeitsreihenfolge ein. Jede Produktänderung beginnt mit einem fehlschlagenden Test. Zwei exakte Mock-URLs, feste Snapshot-Termine und öffentliche Test-Helper-Schnittstellen beseitigen Zufalls- und Interpretationsspielraum. Der bekannte JWT-Baseline-Fehler bleibt als separater Vergleichspunkt sichtbar.
- **Fehlversuche oder Blocker:** Keine Implementierungsversuche; die Plan-Selbstprüfung fand und beseitigte drei Dokumentationsunschärfen: eine unvollständig erklärte Test-Szenario-API, einen nicht eigenständig ausführbaren Frontend-Testbefehl und einen nur relativ beschriebenen Mock-Termin. Ein erster rein lesender Verifikationsbefehl scheiterte an fehlerhafter Shell-Quotierung und wurde korrigiert wiederholt. Eine zunächst zu einfache Pfadprüfung meldete sechs gültige `Modify`-Pfade, die laut Aufgabenreihenfolge erst zuvor erstellt werden; die sequenzbewusste Wiederholung bestätigte null ungültige Pfade.
- **Korrekturen durch den Benutzer:** Keine
- **Besonders hilfreich:** Die Vorgabe kleiner Red-Green-Schritte zwang den Plan, Verhalten, betroffene Dateien, Schnittstellen, Prüfbefehle und Commitgrenzen gemeinsam sichtbar zu machen. Dadurch kann ein frischer Kontext jede Aufgabe ohne Zugriff auf Matt-Artefakte aufnehmen.
- **Unnötig oder zu aufwendig:** **Agentenentwurf:** Der 12-Aufgaben-Plan ist mit mehr als 1.500 Zeilen sehr ausführlich. Diese Detailtiefe verbessert Reproduzierbarkeit, erhöht aber Lese- und Pflegeaufwand und muss im Vergleich mit dem Matt-Versuch ausdrücklich bewertet werden.
- **Vom Skill übersehen:** **Agentenentwurf:** `writing-plans` erfasst keine Experimentmetriken und kennt den vorbestehenden JWT-Baseline-Fehler nicht; beides musste aus dem projektspezifischen Versuchsprotokoll ergänzt werden.
- **Was ich selbst gelernt habe:** Kein separates persönliches Lernergebnis nur
  für S2 wurde erhoben. In S5 nannte der Benutzer übergreifend das Zusammenspiel
  von Backend, Datenbank und Frontend; außerdem bewertete er die eigene Kontrolle
  über Architektur und Ausführungsform positiv.
- **Nachweis:** `Docs/superpowers/plans/2026-08-28-moodle-end-to-end.md`; verknüpfter Worktree `/Users/saburollahsafari/Documents/study-organizer/.worktrees/superpowers`; Branch `experiment/superpowers`; `e7d8b5e` ist Vorfahr von `HEAD`

### Superpowers S3 — Implementierung und TDD (abgeschlossen)

- **Beginn/Ende:** 28. August 2026, 12:47 CEST / 30. August 2026, 06:39 CEST; ca. 41 h 52 min Wandzeit, aktive Benutzerzeit nicht separat gemessen
- **Verwendete Skills:** `subagent-driven-development` für Tasks 1–6; `executing-plans` inline für Tasks 7–12; durchgehend `test-driven-development`, bei Fehlern `systematic-debugging`; bestehende Isolation gemäß `using-git-worktrees`
- **Erzeugte Artefakte:** Git-ignorierter, planspezifischer SDD-Ledger unter `.superpowers/sdd/2026-08-28-moodle-end-to-end/`; Task-Briefs, Implementierungsberichte und Review-Pakete folgen dort
- **Gestellte Rückfragen:** Der Benutzer wählte Ausführungsform 1, die empfohlene subagentengesteuerte Umsetzung. Der Skill läuft danach ohne routinemäßige Zwischenfreigaben weiter.
- **Wichtige Entscheidungen:** Vor Task 1 wurden alle taskübergreifend geteilten Dateien und Schnittstellen sowie die innere Konsistenz jeder Aufgabe tabellarisch geprüft. Drei Rulings sind im Ledger festgehalten: Application-Platzierung des portnahen Snapshot-Diffs, keine Produktionsabhängigkeit auf spätere Test-Fixtures und ein einheitlicher Test-Helper-Propertyname.
- **Fehlversuche oder Blocker:** Das mitgelieferte Skript `sdd-workspace` besitzt kein Ausführungsbit und musste unverändert über `bash` gestartet werden. `task-brief` ruft dieses Skript intern direkt auf; der erste Aufruf scheiterte daher ebenfalls und wurde mit dem dokumentierten expliziten Ausgabepfad erfolgreich wiederholt.
- **Subagent-Ereignis:** Der erste Task-4-Fixturn endete vor Änderungen mit dem vom Agentendienst gemeldeten Nutzungslimit. Der Arbeitsbaum blieb sauber; gemäß `subagent-driven-development` wurde dieselbe Fixrunde mit Brief, Bericht und Findings an einen frischen Agenten übergeben.
- **Subagent-Ereignis:** Der Task-5-Fixagent erreichte sein Nutzungslimit nach vollständigem RED/GREEN-Bericht, aber vor dem Commit. Zwei uncommittete Fixdateien blieben erhalten und wurden einem frischen Agenten zur unabhängigen Verifikation und Übernahme übergeben.
- **Subagent-Ereignis:** Task 6 wurde mit 122/122 grünen Backend-Tests implementiert. Der Review fand keine Produktionslücke, aber drei Important-Testlücken in Past-Due-Materialisierung, Description-Synchronisierung und vollständiger Safe-Error-/Last-Success-Abdeckung. Der erste Fixturn endete nach Teständerungen am Nutzungslimit. Ein frischer Verifikationsturn wurde auf korrigierte Benutzeranweisung gestoppt; seine temporäre Due-Date-Mutation wurde erkannt und exakt zurückgesetzt. Inline bestanden anschließend 63/63 fokussierte und 63/63 volle Infrastructure-Tests.
- **Ausführungsmodus:** Nach Task 6 ersetzte der Benutzer die subagentengesteuerte Ausführung für Tasks 7–12 durch einen Single-Agent-/Inline-Workflow. Plan und TDD bleiben bindend; es gibt keine Per-Task-Reviewer oder wiederholten Review-/Fixschleifen und genau einen Gesamt-Review nach Task 12.
- **Review-Funde:** Task 1: ein Critical-Fund, keine Important- oder Minor-Funde. `ScanRun.Fail` akzeptierte zunächst beliebige nichtleere Fehltexte und hätte dadurch Tokens oder Rohantworten speichern können. Fixrunde 1 führte testgetrieben eine geschlossene Safe-Code-Liste ein; der Re-Review bestätigte den Fund als behoben und fand keine neue Regression.
- **Task-Nachweise:** Task 1: `f1abab1 feat: model external course domain`; `8825513 fix: restrict scan run error codes`; RED als erwarteter Compile-Fehler vor dem Domain-Namespace; GREEN 35/35 fokussierte ExternalCourses-Tests. VSTest benötigte wegen der bekannten Loopback-Socket-Sperre dieselbe Sandbox-Ausnahme wie die Baseline.
- **Task-Nachweise:** Task 2: `0a52747 feat: define external course snapshots`; RED wegen fehlendem Application-Namespace und fehlenden Snapshot-Typen; GREEN Application 6/6 und Domain 52/52. Der Task-Review war ohne Fund. Die Läufe meldeten `NU1900`, weil die NuGet-Advisory-Quelle im eingeschränkten Netzwerk nicht erreichbar war; Restore und Tests liefen dennoch vollständig.
- **Task-Nachweise:** Task 3: `17f3022 feat: persist external course state`; RED wegen fehlender DbSets; GREEN Infrastructure 5/5; Build mit 0 Fehlern; Migration mit fünf Tabellen, sieben Fremdschlüsseln, fünf Unique-Indizes und drei Restrict-Aktionen. Review: ein Minor-Fund zur Dispose-Behandlung des Testfixtures, für den Gesamt-Review vorgemerkt. Der bekannte JWT-Baseline-Fehler wurde vom Task-Agenten selbst erneut erkannt.
- **Task-Nachweise:** Task 4: `51c621a feat: register mock Moodle courses`; `4d5a6a4 test: cover external course conflict recovery`; ursprüngliches RED wegen fehlender Contracts/Handler; GREEN nach Korrektur zweier SQLite-`DateTimeOffset`-Sortierfehler; final 31/31 ExternalCourse-Tests. Review: zwei Important-Testlücken in Unique-Retry und Active-Lease-Priorität, durch drei deterministische Tests plus Mutation-Checks behoben; ein Minor zur caller-seitigen Tracker-Bereinigung für den Gesamt-Review vorgemerkt. Ein erster paralleler SQLite-Race-Ansatz wurde wegen Locks verworfen und durch relationale View-/Trigger-Fixtures ersetzt.
- **Task-Nachweise:** Task 5: `634947e feat: scan shared courses idempotently`; `721216f fix: canonicalize external content identities`; RED wegen fehlender StudyTask-Synchronisierung und fehlendem Scanhandler; final Domain 53/53, Application 6/6, Infrastructure 46/46. Review: ein Important-Fund, weil rohe Inhalts-IDs vor der späteren Domain-Trimmung auf Eindeutigkeit geprüft wurden; zwei Regressionstests und eine einmalige Snapshot-Kanonisierung behoben den Fund, Re-Review sauber.
- **Task-Nachweise:** Task 6: `07b81a1 feat: preserve course state across scan changes`; `468a715 test: harden external scan guarantees`; ursprüngliche finale Verifikation Domain 55/55, Application 6/6, Infrastructure 61/61. Review: drei Important-Testlücken ohne belegten Produktionsfehler; geerbte Fixänderungen erweiterten die Infrastructure-Abdeckung auf 63/63 und belegen sichtbare abgelaufene Inhalte, Description-Synchronisierung sowie alle sicheren Providerfehler und Last-Success-Erhalt. Ein `NU1900`-Minor bleibt als Umgebungsrauschen dokumentiert.
- **Task-Nachweise:** Task 7 inline: `3c080d1 feat: protect Moodle-managed study data`; erwartetes Compile-RED, danach 6/6 fokussierte Schutztests und 69/69 volle Infrastructure-Tests. Zwei SQLite-`DateTimeOffset`-Fehler wurden nach `systematic-debugging` durch Client-Sortierung bei weiterhin serverseitiger Owner-/Modulfilterung behoben. Die 31 fokussierten API-Fälle kompilierten, erreichten wegen des unveränderten JWT-Baselinefehlers aber keinen Endpunkt; der Solution-Build bestand mit 0 Fehlern und einem `NU1900`.
- **Task-Nachweise:** Task 8 inline: `c4b7322 feat: expose Moodle course APIs`; erwartetes Compile-RED; nach zwei systematisch eingegrenzten Testhost-Konfigurationsläufen 17/17 neue, vollständig konfigurierte API-Tests grün. Der Plan nahm an, dass `ConfigureAppConfiguration` allein die bereits vor Host-Build gelesenen `Program`-Werte erreicht; zusätzlich war deshalb derselbe frühe Umgebungsbootstrap wie in den bestehenden API-Tests nötig. Solution-Build bestand mit 0 Fehlern und einem `NU1900`.
- **Task-Nachweise:** Task 9 inline: `1e41522 feat: add Moodle course client`; erwartetes fehlendes-Service-Import-RED; anschließend 4/4 exakte HTTP-Routentests und vollständiger Frontend-Typecheck grün. Keine Wiederholungs- oder Debugrunde.
- **Task-Nachweise:** Task 10 inline: `0fc36cc feat: add Moodle course workflow`; erwartetes Komponenten-Import-RED, danach 12/12 Komponenten- und 8/8 Routertests. Ein abschließender Planabgleich deckte die zunächst nicht angezeigte fünfte Scan-Kennzahl auf; ein gezieltes RED und minimales GREEN ergänzten sie. Final 24/24 relevante Frontendtests sowie Typecheck und Lint grün.
- **Task-Nachweise:** Task 11 inline: `5ec8b3d feat: identify Moodle-managed tasks`; erwartetes View-RED 2 fehlgeschlagen/17 bestanden, danach 19/19 fokussierte Viewtests und 10/10 angepasste Service-/Dashboardtests. Vollständig 20 Testdateien/97 Tests sowie Typecheck, Lint und Build grün. Externe Tasks zeigen Provenienz bei erhaltenem Statuswechsel; verknüpfte Module bleiben editierbar und sind gegen Löschung gesperrt.
- **Task-Nachweise:** Task 12 inline: `0e0c073 fix: load local settings in isolated worktrees`. Der Benutzer bestätigte den vollständigen Browser-Walkthrough Ende-zu-Ende. Lokale Hindernisse waren fehlende `.env`, abweichendes PostgreSQL-Passwort, inkonsistentes Docker-Volume/Migrationshistorie und Vite-Cache. Repositorybefund: Der Standard-PhysicalFileProvider sah Appsettings unter `.worktrees` trotz vorhandener Dateien nicht; vorhandener CORS-Test RED 0/2, nach gezieltem Fallback 2/2. Kontrollierter Development-Start ohne explizite JWT-/CORS-Werte: Health 200, Preflight 204 mit `Access-Control-Allow-Origin`. ExternalCourse-API 17/17, API gesamt 65/65, Backend gesamt 195/195, Frontend 97/97, Builds/Typecheck/Lint grün. Alle vier EF-Migrationen angewendet. Gegen `e7d8b5e`: 84 Produktdateien, +8.368/−79 Zeilen.
- **Korrekturen durch den Benutzer:** Nach Task 6 ersetzte der Benutzer die zuvor gewählte subagentengesteuerte Ausführung ausdrücklich durch Inline-Ausführung für Tasks 7–12; Task 6 durfte nicht neu implementiert werden. In Task 12 korrigierte der manuelle Walkthrough die zu frühe Agentenaussage, der Root-Start mit exaktem `.csproj` und Launch-Profil lade die Konfiguration bereits korrekt.
- **Besonders hilfreich:** Die Kombination aus bestehendem fokussiertem CORS-Test, redigierter Provider-Diagnostik und vom Benutzer ausgeführtem Sichtlauf trennte Produktlücke, Testreihenfolge und lokale Datenzustände nachvollziehbar.
- **Unnötig oder zu aufwendig:** 23 zusätzliche Sandbox-Eskalationen in Task 12 und mehrere kurzfristige Diagnose-Builds erhöhten den Ausführungsaufwand; zwei Hypothesen zu Launch-Profil beziehungsweise Environment allein reichten nicht.
- **Vom Skill übersehen:** Der Plan behandelte den vorgeschriebenen versteckten Worktree als isolierte Git-Frage, nicht als Einfluss auf `PhysicalFileProvider` und damit Appsettings/CORS/JWT-Startup. Ebenso fehlten ein Schema-Historiencheck und Vite-Cache-Hinweis im ursprünglichen Walkthrough.
- **Was ich selbst gelernt habe:** Vom Benutzer praktisch bestätigt: Ein grüner automatisierter Schnitt ersetzt den lokalen Sichtlauf nicht; Environment, Content-Root, FileProvider, Migrationshistorie, Secret-/Passwortabgleich und Frontend-Cache sind getrennte Startgrenzen und müssen jeweils beobachtbar geprüft werden.
- **Nachweis:** SDD-Ledger; Task-Berichte; Commits bis `c43caa4`; exakte Test-/Buildausgaben und Benutzerbericht zum manuellen Walkthrough

### Finaler Inline-Gesamtreview

Der genau einmal ausgeführte Abschlussreview fand keine offenen Critical- oder
Important-Probleme in Spezifikationskonformität, Owner-Scoping, relationalen
Constraints, sicherer Fehlerabbildung, Scan-/Registrierungsatomizität oder den
UI-Schutzregeln. Ein Minor in der README wurde unmittelbar korrigiert: Der
reproduzierbare Backend-Start zeigt jetzt den zuvor fehlerhaften und durch
`Program.cs` reparierten Befehl direkt vom Repository-Root.

Der exakte Root-Start lief anschließend ohne explizite JWT- oder CORS-
Umgebungsvariablen auf Port 5102: Development-Environment und Content-Root waren
korrekt, `/health` antwortete mit HTTP 200 und der CORS-Preflight für
`http://localhost:5173` mit HTTP 204 samt passendem Allow-Origin-Header. Der
Prozess wurde danach beendet. Offen bleiben nur drei nicht blockierende Minor-
Beobachtungen: zwei ausschließlich testinterne Robustheitsdetails
(Dispose-Fehlerpfad und redundantes Tracker-Clear) sowie `NU1900` bei nicht
erreichbarer NuGet-Advisory-Quelle. Sie verändern weder Produktverhalten noch
Abnahmeergebnis.

### Superpowers S4 — Review und Branch-Abschluss (abgeschlossen)

- **Beginn/Ende:** 30. August 2026, nach Task 12 bis ca. 13:06 CEST
- **Verwendete Skills:** `requesting-code-review` als Inline-Prüfraster wegen
  des ausdrücklichen Subagent-Verbots, `verification-before-completion` und
  `finishing-a-development-branch`
- **Erzeugte Artefakte:** Abschlussreview im Aktivitäts- und Beobachtungslog;
  README-Korrektur; Commits `b6c9642` und die vorherigen Task-12-Commits
- **Gestellte Rückfragen:** drei vorgegebene Integrationsoptionen nach frischem
  Testlauf
- **Wichtige Entscheidungen:** Der Benutzer wählte Option 3. Branch
  `experiment/superpowers` und Worktree `.worktrees/superpowers` bleiben
  isoliert; kein Merge nach `main`, kein Push und kein Pull Request vor
  Reflexion und fairem Matt-Vergleich.
- **Fehlversuche oder Blocker:** Der kontrollierte Root-Start hing zunächst in
  der Sandbox und lief nach der bekannten lokalen Prozessfreigabe. Keine
  Produkt- oder Testfehler.
- **Korrekturen durch den Benutzer:** Keine neue Produktkorrektur; die bereits
  dokumentierte Startup-Korrektur blieb Grundlage der README-Abnahme.
- **Besonders hilfreich:** Der exakte, zuvor problematische Root-Befehl wurde
  ohne JWT-/CORS-Overrides mit Health 200 und CORS 204 nachgewiesen.
- **Unnötig oder zu aufwendig:** Der Abschluss-Skill verlangte trotz der kurz
  zuvor abgeschlossenen Verifikation einen weiteren vollständigen Testlauf.
- **Vom Skill übersehen:** Der Skill kennt die experimentelle Forderung, beide
  Branches bis zum Vergleich getrennt zu halten, nicht; deshalb war Option 3
  fachlich klar vorzuziehen.
- **Was ich selbst gelernt habe:** **Vom Benutzer bestätigt:** Der manuelle
  End-to-End-Test war der wichtigste Vertrauensnachweis; gleichzeitig musste der
  lokale Start mehrere getrennte Konfigurations- und Datenzustände berücksichtigen.
- **Nachweis:** Backend erneut 195/195, Frontend erneut 97/97; Branchentscheidung
  des Benutzers; Commit `b6c9642`

### Superpowers S5 — Benutzerreflexion (abgeschlossen)

- **Beginn/Ende:** 30. August 2026, unmittelbar nach S4
- **Verwendete Skills:** `using-superpowers` zur Einordnung des nächsten
  Protokollschritts
- **Erzeugte Artefakte:** vollständig ausgefüllte subjektive Bewertung
- **Gestellte Rückfragen:** sieben Kriterien einzeln; drei kurze Rückfragen für
  Beispiele oder eine verständlichere Erklärung
- **Wichtige Entscheidungen:** Die Antworten wurden sprachlich bereinigt, aber
  inhaltlich nicht erweitert. Anpassbarkeit wurde nach Erklärung des Kriteriums
  vom zunächst ohne Verständnis genannten Wert 4 auf 3 korrigiert.
- **Fehlversuche oder Blocker:** Die Bedeutung von „Anpassbarkeit“ war zunächst
  nicht verständlich und wurde anhand des Inline-Wechsels, Browser-Walkthroughs
  und Startup-Problems neu erklärt.
- **Korrekturen durch den Benutzer:** Anpassbarkeit final 3/5 statt 4/5.
- **Besonders hilfreich:** Einzelne Fragen machten jede Bewertung mit einem
  konkreten Beispiel nachvollziehbar.
- **Unnötig oder zu aufwendig:** Für drei Kriterien war eine zusätzliche
  Rückfrage nötig, weil zunächst nur die Zahl genannt wurde.
- **Vom Skill übersehen:** Das Versuchsprotokoll definiert die Skala, liefert
  aber keine leicht verständlichen, projektnahen Beispiele für jedes Kriterium.
- **Was ich selbst gelernt habe:** **Vom Benutzer bestätigt:** Besonders klar
  wurde das Zusammenspiel von Backend, Datenbank und Frontend. Der strukturierte
  Ablauf war hilfreich, verbrauchte aber viel Agentenkontingent; beim lokalen
  Start musste der Benutzer mehrere Fehler selbst korrigieren.
- **Nachweis:** Antworten des Benutzers in dieser Sitzung

| Kriterium | Wert | Konkretes Beispiel des Benutzers |
| --- | ---: | --- |
| Verständlichkeit | 5 | Der Arbeitsablauf war kurz, sauber und leicht nachvollziehbar. |
| Kontrolle | 4 | Architektur und Ausführungsform konnten selbst bestimmt werden. |
| Lerngewinn | 4 | Das Zusammenspiel von Backend, Datenbank und Frontend wurde verständlicher. |
| Angemessener Aufwand | 5 | Superpowers nutzte eine sehr gute Struktur. |
| Vertrauen | 5 | Der manuelle End-to-End-Test bestätigte, dass alles sehr gut funktioniert. |
| Wiederaufnahme | 4 | Die Fortsetzung wurde erleichtert, verbrauchte aber viel Agentenkontingent. |
| Anpassbarkeit | 3 | Das Backend ließ sich zunächst nicht starten; mehrere lokale Fehler mussten selbst korrigiert werden. |

**Mittelwert:** 4,29 von 5 Punkten. Der Mittelwert dient nur als kompakte
Übersicht; die konkreten Beispiele und Unterschiede zwischen den Kriterien sind
für den Vergleich aussagekräftiger.
